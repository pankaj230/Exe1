import calendar
year=int(input())
month=int(input())
count=0
n=year
while(n>0):
    count=count+1
    n=n//10
if(month>12 or count!=4):
    print("Invalid Input ")
else:
    print(calendar.month(year ,month))