def removeThirdNumber(int_list):
    position= 2-1
    index=0
    len_list=(len(int_list))
    while(len_list>0):
        index=(position+index)%len_list
        print(int_list.pop(index))
        len_list -= 1
n=int(input())
int_list=[]
for i in range(n):
    int_list.append(int(input()))
removeThirdNumber(int_list)